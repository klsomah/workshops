﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Azure.Messaging.ServiceBus;

namespace MMO.Xrm.GroupSales.AzureFunctions.BusinessLogic.Interfaces
{
    public interface IMessageProcessingBusinessLogic
    {
		Task<Task> SubmitQuote(QrsPayload payload, DateTime triggerTimestamp);
		Task<Task> CompleteQuote(QrsPayload payload, DateTime triggerTimestamp);
		Task<Task> RenewQuote(QrsPayload payload, DateTime triggerTimestamp);
        Task ScheduledJobs();
    }
}
