﻿using Microsoft.Data.SqlClient;

namespace MMO.Xrm.GroupSales.AzureFunctions.BusinessLogic
{
    public static class OnBaseHelper
    {
        public static List<OnBaseData> GetOnBaseOpenRecords(string? qrsIds)
        {
            var connectionString = Environment.GetEnvironmentVariable("OnBaseConnectionString");

            var query = $@"SELECT TOP 100
                                ki114.keyvaluechar as GroupID
                                ,ki218.keyvaluechar as GroupName 
                                ,ki2932.keyvaluechar as QRSID
                                ,lcs.statename as QueueName
                                ,lcs.statenum as QueueNum
                                ,ki1318.keyvaluechar as MBStatus
                                ,itd.datestored LastUpdated
                            FROM hsi.itemdata itd
                                LEFT JOIN hsi.keyitem114 ki114 on ki114.itemnum = itd.itemnum
                                LEFT JOIN hsi.keyitem218 ki218 on ki218.itemnum = itd.itemnum
                                LEFT JOIN hsi.keyitem2932 ki2932 on ki2932.itemnum = itd.itemnum
                                LEFT JOIN hsi.keyitem318 ki1318 on ki1318.itemnum = itd.itemnum
                                LEFT JOIN hsi.itemlc ilc on ilc.itemnum = itd.itemnum
                                LEFT JOIN hsi.lcstate lcs on ilc.statenum = lcs.statenum
                            WHERE itd.itemtypenum = 848
                                AND ki2932.keyvaluechar IS NOT NULL
                                AND ki2932.keyvaluechar IN ({qrsIds})
                            ORDER BY itd.datestored DESC";

            var results = new List<OnBaseData>();

            using var connection = new SqlConnection(connectionString);
            connection.Open();
            using SqlCommand command = new SqlCommand(query, connection);
            using SqlDataReader reader = command.ExecuteReader();

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    OnBaseData data = new OnBaseData
                    {
                        GroupId = reader[0].ToString()?.Trim(),
                        GroupName = reader[1].ToString()?.Trim(),
                        QrsId = reader[2].ToString()?.Trim(),
                        QueueName = reader[3].ToString()?.Trim(),
                        QueueNum = reader[4].ToString()?.Trim(),
                        MbStatus = reader[5].ToString()?.Trim()
                    };
                    results.Add(data);
                }
            }
            reader.Close();

            return results;
        }

        public static string? GetQueueName(string? queueNum)
        {
            var connectionString = Environment.GetEnvironmentVariable("OnBaseConnectionString");
            var queueName = "";

            var query = $@"SELECT TOP 1
                    lcs.statename as QueueName
                    ,lcs.statenum as QueueNum
                    FROM hsi.itemdata itd
                    LEFT JOIN hsi.itemlc ilc on ilc.itemnum = itd.itemnum
                    LEFT JOIN hsi.lcstate lcs on ilc.statenum = lcs.statenum
                    WHERE itd.itemtypenum = 848
                    AND lcs.statenum = '{queueNum}'";

            using var connection = new SqlConnection(connectionString);
            connection.Open();
            using SqlCommand command = new SqlCommand(query, connection);
            using SqlDataReader reader = command.ExecuteReader();

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    queueName = reader[0].ToString()?.Trim();
                }
            }
            reader.Close();

            return queueName;
        }
    }

    public class OnBaseData
    {
        public string? GroupId { get; set; }
        public string? GroupName { get; set; }
        public string? QrsId { get; set; }
        public string? QueueName { get; set; }
        public string? QueueNum { get; set; }
        public string? MbStatus { get; set; }

    }
}
