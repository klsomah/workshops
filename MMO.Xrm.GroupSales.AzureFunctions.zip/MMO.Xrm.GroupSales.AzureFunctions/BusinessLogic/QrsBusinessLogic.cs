﻿using System.Globalization;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Extensions.Logging;
using Microsoft.PowerPlatform.Dataverse.Client;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using MMO.Xrm.GroupSales.AzureFunctions.BusinessLogic.Interfaces;
using MMO.Xrm.Model;

namespace MMO.Xrm.GroupSales.AzureFunctions.BusinessLogic
{
    public class QrsBusinessLogic : IMessageProcessingBusinessLogic
    {
        private readonly ILogger<QrsBusinessLogic> _logger;
        private readonly IOrganizationServiceAsync2 _serviceClient;

        public QrsBusinessLogic(ILogger<QrsBusinessLogic> logger, IOrganizationServiceAsync2 serviceClient)
        {
            _logger = logger;
            _serviceClient = serviceClient;
        }

		public async Task<Task> SubmitQuote(QrsPayload payload, DateTime triggerTimestamp)
		{
			if (payload == null)
			{
				_logger.LogError("FormFire Submission payload is null, exiting SubmitQuote()");
				return Task.CompletedTask;
			}

			// Ensure the Quote doesn't already exist for the QRS Quote ID
			var leads = CrmHelper.GetLeadsMmoQrsQuoteId(_serviceClient, payload!.qrsQuoteId);

			if (leads.Entities?.Count > 0)
			{
				throw new Exception($"Lead found for QRS Quote ID: {payload.qrsQuoteId}. A new lead will not be created.");
			}

			await CreateLead(payload, triggerTimestamp);

			return Task.CompletedTask;
		}

        public async Task<Task> CompleteQuote(QrsPayload payload, DateTime triggerTimestamp)
        {
            if (payload == null)
            {
				_logger.LogError("Complete Quote payload is null, exiting SubmitQuote()");
				return Task.CompletedTask;
            }

            var opportunities = CrmHelper.GetOpportunitiesByMmoQrsQuoteId(_serviceClient, payload!.qrsQuoteId);
            if (opportunities.Entities?.Count > 1)
            {
                throw new Exception($"Multiple Opportunities found for QRS Quote ID: {payload.qrsQuoteId}");
            }
            var opportunity = opportunities.Entities?.FirstOrDefault();
            			
			var opportunityHasQuote = opportunity != null && opportunity.Contains(Opportunity.Fields.MMo_QRS_QuoteId_Text);
            if (!opportunityHasQuote)
            {
                _logger.LogWarning($"Opportunity not found for QRS Quote ID: {payload.qrsQuoteId}");
                return Task.CompletedTask;
            }

            if (opportunity != null)
            {
				// Prevent out of sequence processing
				opportunity.TryGetAttributeValue<DateTime>(Opportunity.Fields.MMo_Integration_Modified_On, out DateTime integrationModifiedOn);
				if (integrationModifiedOn > triggerTimestamp)
				{
					throw new Exception($"Stale Data due to TriggerTimestamp.");
				}

				await UpsertOpportunity(opportunity.Id, payload, QrsMessageType.Complete, triggerTimestamp);
            }

            return Task.CompletedTask;
        }

		public async Task<Task> RenewQuote(QrsPayload payload, DateTime triggerTimestamp)
        {
            if (payload == null)
            {
				_logger.LogError("Renewal payload is null, exiting RenewQuote()");
				return Task.CompletedTask;
            }

			// Find an existing Opportunity
			var opportunities = CrmHelper.GetOpportunitiesByMmoQrsQuoteId(_serviceClient, payload!.qrsQuoteId);

			if (opportunities.Entities.Count == 0)
			{
				// Create new Opportunity
				await UpsertOpportunity(Guid.Empty, payload, QrsMessageType.Renew, triggerTimestamp);
			}
			else
			{
				if (opportunities.Entities.Count > 1)
				{
					_logger.LogWarning($"Multiple Opportunities found for QRS Quote ID:{payload!.qrsQuoteId}.  All Opportunities found will be updated.");
				}

				foreach (var opportunity in opportunities.Entities)
				{
					// Update Opportunity
					if (opportunity != null)
					{
						// Prevent out of sequence processing
						opportunity.TryGetAttributeValue<DateTime>(Opportunity.Fields.MMo_Integration_Modified_On, out DateTime integrationModifiedOn);
						if (integrationModifiedOn > triggerTimestamp)
						{
							throw new Exception($"Stale Data due to TriggerTimestamp.");
						}

						await UpsertOpportunity(opportunity.Id, payload, QrsMessageType.Renew, triggerTimestamp);
					}
				}
			}

			return Task.CompletedTask;
		}

		/// <summary>
		/// Upsert an Opportunity
		/// </summary>
		/// <param name="opportunityId"></param>
		/// <param name="qrsPayload"></param>
		/// <param name="qrsMessageType"></param>
		/// <returns></returns>
		public async Task UpsertOpportunity(Guid opportunityId, QrsPayload qrsPayload, QrsMessageType qrsMessageType, DateTime triggerTimestamp)
		{
			var opportunity = new Entity(Opportunity.EntityLogicalName, opportunityId);
			var isCreate = opportunityId == Guid.Empty;

			// Set MMO Integration Modified on to Trigger Timestamp.
			opportunity[Opportunity.Fields.MMo_Integration_Modified_On] = triggerTimestamp;

			// Set common fields
			SetOpportunityFields_Shared(opportunity, qrsPayload);

			// Set fields unique to integration type
			switch (qrsMessageType)
			{
				case QrsMessageType.Submit:
					break;
				case QrsMessageType.Complete:
					await SetOpportunityFields_Complete(opportunity, qrsPayload, triggerTimestamp);
					break;
				case QrsMessageType.Renew:
					await SetOpportunityFields_Renew(opportunity, qrsPayload, isCreate, triggerTimestamp);
					break;
				default:
					break;
			}

			try
			{
				var upsertResponse = await _serviceClient.ExecuteAsync(new UpsertRequest { Target = opportunity });
			}
			catch (Exception ex)
			{
				// Check if the exception is due to missing privileges
				if (ex.Message.Contains("missing prvReadOpportunity privilege"))
				{
					// Log the error
					_logger.LogError($"User does not have the required privileges: {ex.Message}");

					// Set the owner to the small group team instead.  Passing in null will return team.
					opportunity[Opportunity.Fields.OwnerId] = GetSmallGroupSalesConsultant(null);

					var upsertResponse = await _serviceClient.ExecuteAsync(new UpsertRequest { Target = opportunity });
				}
				else
				{
					// Rethrow the exception if it's not related to privileges
					throw;
				}
			}
		}

        /// <summary>
        /// Update Opportunity Status
        /// </summary>
        /// <param name="opportunityId"></param>
        /// <param name="lastUpdatedQueue"></param>
        /// <param name="updateStateCode"></param>
        /// <param name="completedDate"></param>
        /// <returns></returns>
        public void UpdateOpportunityStatus(Guid opportunityId, int lastUpdatedQueue, bool updateStateCode, DateTime? completedDate)
        {
            var opportunity = new Entity(Opportunity.EntityLogicalName, opportunityId)
                {
                    [Opportunity.Fields.MMo_Last_Tracked_OnBase_Queue] = lastUpdatedQueue
                };

            if (completedDate != null && updateStateCode)
            {
				opportunity[Opportunity.Fields.MMo_Underwriting_Completed_Date] = completedDate;
            }

            if (updateStateCode)
            {
                opportunity[Opportunity.Fields.MMo_OnBase_Status_Code] = new OptionSetValue((int)MMo_OnBase_Status_Gc.Complete);
            }
            else
            {
                opportunity[Opportunity.Fields.MMo_OnBase_Status_Code] = new OptionSetValue((int)MMo_OnBase_Status_Gc.InProcess);
            }
            _serviceClient.Update(opportunity);
		}

		/// <summary>
		/// Set shared Opportunity fields
		/// </summary>
		/// <param name="opportunity"></param>
		/// <param name="qrsPayload"></param>
		/// <returns></returns>
		private void SetOpportunityFields_Shared(Entity opportunity, QrsPayload qrsPayload)
		{
			if (!string.IsNullOrWhiteSpace(qrsPayload.qrsQuoteStatus))
			{
				var status = CrmHelper.QrsQuoteStatus(qrsPayload.qrsQuoteStatus);
				opportunity[Opportunity.Fields.MMo_QRS_Status_Choice] = new OptionSetValue(Convert.ToInt32(status));
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.quoteEffectiveDate))
			{
				opportunity[Opportunity.Fields.MMo_Effective_Date] = DateTime.Parse(qrsPayload.quoteEffectiveDate, null, DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal);
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.eligibleCount))
			{
				opportunity[Opportunity.Fields.MMo_Total_Eligible_Employees] = Convert.ToInt32(qrsPayload.eligibleCount);
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.totalCount))
			{
				opportunity[Opportunity.Fields.HsL_TotalEmployees] = Convert.ToInt32(qrsPayload.totalCount);
				opportunity[Opportunity.Fields.MMo_Total_Number_Of_Employees] = Convert.ToInt32(qrsPayload.totalCount);
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.agencyId))
			{
				var accountId = GetAccountId(qrsPayload.agencyId, (int)MMo_AccountType_Code.Broker);
				if (accountId != Guid.Empty)
				{
					opportunity[Opportunity.Fields.MMo_Broker_Agency_Id] = new EntityReference(Account.EntityLogicalName, accountId); //not in D365
				}
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.agentId))
			{
				var contact = GetContactId(qrsPayload.agentId);
				if (contact != null)
				{
					opportunity[Opportunity.Fields.MMo_Broker_Name_Id] = new EntityReference(Contact.EntityLogicalName, contact.Id);
				}
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.groupName))
			{
				opportunity[Opportunity.Fields.Name] = qrsPayload.groupName;
				opportunity[Opportunity.Fields.MMo_Company_Name] = qrsPayload.groupName;
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.coverageIndicator))
			{
				var indicator = CrmHelper.CoverageIndicator(qrsPayload.coverageIndicator);
				opportunity[Opportunity.Fields.MMo_Coverage_Indicator_Choice] = new OptionSetValue(indicator);
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.emc))
			{
				opportunity[Opportunity.Fields.MMo_EMc] = Convert.ToDecimal(qrsPayload.emc);
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.totalCount))
			{
				var count = CrmHelper.EmployeeCount(Convert.ToInt32(qrsPayload.totalCount));
				opportunity[Opportunity.Fields.MMo_Market_Segment_Choice] = new OptionSetValue(count);
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.tier))
			{
				var tier = CrmHelper.MedicalTier(Convert.ToInt32(qrsPayload.tier));
				if (tier > 0)
				{
					opportunity[Opportunity.Fields.MMo_Medical_Tier_Choice] = new OptionSetValue(tier);
				}
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.countyCode))
			{
				var county = GetCountyId(qrsPayload.countyCode);
				if (county != null)
				{
					var region = (OptionSetValue)county[MMo_County.Fields.MMo_Region];
					if (region != null)
					{
						opportunity[Opportunity.Fields.MMo_Region_Choice] = region;
					}
				}
			}
		}

		/// <summary>
		/// Set Opportunity fields when processing Complete
		/// </summary>
		/// <param name="opportunity"></param>
		/// <param name="qrsPayload"></param>
		/// <returns></returns>
		private async Task SetOpportunityFields_Complete(Entity opportunity, QrsPayload qrsPayload, DateTime triggerTimestamp)
		{
			if (!string.IsNullOrWhiteSpace(qrsPayload.ein))
			{
				var accountId = GetAccountIdByEin(qrsPayload.ein);

				if (accountId == Guid.Empty)
				{
					accountId = await CreateAccount(qrsPayload, triggerTimestamp);
				}

				opportunity[Opportunity.Fields.CustomerId] = new EntityReference(Account.EntityLogicalName, accountId);
				opportunity[Opportunity.Fields.ParentAccountId] = new EntityReference(Account.EntityLogicalName, accountId);
			}
		}

		/// <summary>
		/// Set Opportunity fields when processing Renewals
		/// </summary>
		/// <param name="opportunity"></param>
		/// <param name="qrsPayload"></param>
		/// <param name="isCreate"></param>
		/// <returns></returns>
		private async Task SetOpportunityFields_Renew(Entity opportunity, QrsPayload qrsPayload, bool isCreate, DateTime triggerTimestamp)
		{
			// Fields to set only when creating an opportunity
			if (isCreate)
			{
				if (!string.IsNullOrWhiteSpace(qrsPayload.qrsQuoteId))
				{
					// If Opportunity ID is an empty Guid, we will create a new opportunity and need to set the QRS Quote ID
					opportunity[Opportunity.Fields.MMo_QRS_QuoteId_Text] = qrsPayload.qrsQuoteId;
					opportunity[Opportunity.Fields.MMo_Integration_Source_Id_Text] = $"QRS-{qrsPayload.qrsQuoteId}";
				}

				// Defaults
				opportunity[Opportunity.Fields.MMo_Business_Area_Choice] = new OptionSetValue((int)MMo_Business_Area_Gc.GroupSales);
				opportunity[Opportunity.Fields.StateCode] = new OptionSetValue((int)Opportunity_StateCode.Open);
				opportunity[Opportunity.Fields.StatusCode] = new OptionSetValue((int)Opportunity_StatusCode.InProgress);
				opportunity[Opportunity.Fields.MMo_Opportunity_Type_Choice] = new OptionSetValue((int)MMo_Opportunity_Type_Gc.Renewal);

				// Set Owner
				var owner = GetSmallGroupSalesConsultant(qrsPayload.agentId);
				if (owner != null && owner.Id != Guid.Empty)
				{
					opportunity[Opportunity.Fields.OwnerId] = owner;
				}

				if (!string.IsNullOrWhiteSpace(qrsPayload.approvedDate)) 
				{ 
					opportunity[Opportunity.Fields.OverriddenCreatedOn] = DateTime.Parse(qrsPayload.approvedDate, null, DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal);
				}
			}

			// Fields to set on both create and update
			if (!string.IsNullOrWhiteSpace(qrsPayload.coverageIndicator))
			{
				opportunity[Opportunity.Fields.MMo_PlanType] = qrsPayload.coverageIndicator;
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.renewalDate))
			{
				opportunity[Opportunity.Fields.MMo_Renewal_Date] = DateTime.Parse(qrsPayload.renewalDate, null, DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal);
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.groupNumber))
			{
				var accountId = Guid.Empty;

				// Find Account by Group Number
				var accounts = CrmHelper.GetAccountByGroupNumber(_serviceClient, qrsPayload.groupNumber);

				if (accounts.Entities.Count > 0)
				{
					// Use the account id found by Group Number
					accountId = accounts.Entities[0].Id;
				}
				else
				{
					// If an Account cannot be found by Group Number, try to find an account by EIN.
					if (!string.IsNullOrWhiteSpace(qrsPayload.ein))
					{
						//accountId = GetAccountId(qrsPayload.ein, (int)MMo_AccountType_Code.Group);
						accountId = GetAccountIdByEin(qrsPayload.ein);
					}
				}

				// If an account was not found in the above logic, create the Employer Group account
				if (accountId == Guid.Empty)
				{
					accountId = await CreateAccount(qrsPayload, triggerTimestamp, MMo_AccountType_Code.EmployerGroup);
				}

				if (accountId != Guid.Empty)
				{
					opportunity[Opportunity.Fields.CustomerId] = new EntityReference(Account.EntityLogicalName, accountId);
					opportunity[Opportunity.Fields.ParentAccountId] = new EntityReference(Account.EntityLogicalName, accountId);
				}
			}
		}

		public async Task<Guid> CreateAccount(QrsPayload qrsPayload, DateTime triggerTimestamp, MMo_AccountType_Code accountTypeCode = MMo_AccountType_Code.ProviderGroup)
		{
			var account = new Entity(Account.EntityLogicalName);

			// Set MMO Integration Modified on to Trigger Timestamp.
			account[Account.Fields.MMo_Integration_Modified_On] = triggerTimestamp;

			//bool consultantFound = false;
			if (!string.IsNullOrWhiteSpace(qrsPayload.groupName))
			{
				account[Account.Fields.Name] = qrsPayload.groupName;
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.streetAddress1))
			{
				account[Account.Fields.Address1_Line1] = qrsPayload.streetAddress1;
				account[Account.Fields.Address2_Line1] = qrsPayload.streetAddress1;
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.streetAddress2))
			{
				account[Account.Fields.Address1_Line2] = qrsPayload.streetAddress2;
				account[Account.Fields.Address2_Line2] = qrsPayload.streetAddress2;
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.city))
			{
				account[Account.Fields.Address1_City] = qrsPayload.city;
				account[Account.Fields.Address2_City] = qrsPayload.city;
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.state))
			{
				account[Account.Fields.Address1_StateOrProvince] = qrsPayload.state;
				account[Account.Fields.Address2_StateOrProvince] = qrsPayload.state;
				
				var stateId = GetStateId(qrsPayload.state);
				if (stateId != Guid.Empty)
				{
					account[Account.Fields.MMo_State_Physical_Id] = new EntityReference(HsL_State.EntityLogicalName, stateId);
					account[Account.Fields.MMo_StateId_Mailing] = new EntityReference(HsL_State.EntityLogicalName, stateId);
				}
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.countyCode))
			{
				var county = GetCountyId(qrsPayload.countyCode);
				if (county != null)
				{
					account[Account.Fields.Address1_County] = county[MMo_County.Fields.MMo_Name];
					account[Account.Fields.Address2_County] = county[MMo_County.Fields.MMo_Name];
					account[Account.Fields.MMo_Address1_County_Id] = new EntityReference(MMo_County.EntityLogicalName, county.Id);
					account[Account.Fields.MMo_Address2_County_Id] = new EntityReference(MMo_County.EntityLogicalName, county.Id);
					
					var region = (OptionSetValue)county[MMo_County.Fields.MMo_Region];
					if (region != null)
					{
						account[Account.Fields.MMo_Region_Choice] = region;
					}
				}
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.zip))
			{
				account[Account.Fields.Address1_PostalCode] = qrsPayload.zip;
				account[Account.Fields.Address2_PostalCode] = qrsPayload.zip;
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.ein))
			{
				account[Account.Fields.HsL_FederalTaxId] = qrsPayload.ein;
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.sic))
			{
				account[Account.Fields.Sic] = qrsPayload.sic;
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.streetAddress1))
			{
				account[Account.Fields.Address1_Line1] = qrsPayload.streetAddress1;
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.eligibleCount))
			{
				account[Account.Fields.HsL_EligibleEmployees] = Convert.ToInt32(qrsPayload.eligibleCount);
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.totalCount))
			{
				account[Account.Fields.HsL_NoOfEmployees] = Convert.ToInt32(qrsPayload.totalCount);
				account[Account.Fields.NumberOfEmployees] = Convert.ToInt32(qrsPayload.totalCount);
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.agencyId))
			{
				var accountId = GetAccountId(qrsPayload.agencyId, (int)MMo_AccountType_Code.Broker);
				if (accountId != Guid.Empty)
				{
					account[Account.Fields.MMo_Broker_Agency_Id] = new EntityReference(Account.EntityLogicalName, accountId); //not in D365
				}
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.agentId))
			{
				var contact = GetContactId(qrsPayload.agentId);
				if (contact != null)
				{
					account[Account.Fields.MMo_Broker_Name_Id] = new EntityReference(Contact.EntityLogicalName, contact.Id);
				}
			}

			// Set Owner
			var owner = GetSmallGroupSalesConsultant(qrsPayload.agentId);
			if (owner != null && owner.Id != Guid.Empty)
			{
				account[Account.Fields.OwnerId] = owner;
			}

			account[Account.Fields.Address1_Country] = "USA";
			account[Account.Fields.Address2_Country] = "USA";

			var country = GetCountryId("USA");
			if (country != null)
			{
				account[Account.Fields.MMo_Country_Physical_Id] = new EntityReference(MMo_Country.EntityLogicalName, country.Id);
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.groupNumber))
			{
				account[Account.Fields.AccountNumber] = qrsPayload.groupNumber;
				account[Account.Fields.HsL_ClientNumber] = qrsPayload.groupNumber;
			}

			account[Account.Fields.MMo_Business_Area_Choice] = new OptionSetValue((int)MMo_Business_Area_Gc.GroupSales); 
			account[Account.Fields.MMo_AccountType_Code] = new OptionSetValue((int)accountTypeCode);
			account[Account.Fields.MMo_Same_Address_Yn] = new OptionSetValue((int)MSeVTmGt_YesOrNo.Yes);

			var accountGuid = await _serviceClient.CreateAsync(account);
			return accountGuid;
		}

		private async Task CreateLead(QrsPayload qrsPayload, DateTime triggerTimestamp)
		{
			var lead = new Entity(Lead.EntityLogicalName);

			// Set MMO Integration Modified on to Trigger Timestamp.
			lead[Lead.Fields.MMo_Integration_Modified_On] = triggerTimestamp;

			lead[Lead.Fields.MMo_Business_Area_Choice] = new OptionSetValue((int)MMo_Business_Area_Gc.GroupSales);
			lead[Lead.Fields.MMo_Data_Scrub_Complete] = true;
			lead[Lead.Fields.MMo_Initial_Data_Scrub_Complete] = new OptionSetValue((int)MSeVTmGt_NoOrYes.Yes);
			lead[Lead.Fields.MMo_Lead_Source_Choice] = new OptionSetValue((int)MMo_Lead_Source_Gc.FormfireEasyappsonline);
			lead[Lead.Fields.MMo_Lead_Stage_Status_Choice] = new OptionSetValue((int)MMo_Lead_Stage_Status_Gc.NewProspect);
			lead[Lead.Fields.MMo_Lead_Type_Choice] = new OptionSetValue((int)MMo_Lead_Type_Gc.NewBusiness);
			lead[Lead.Fields.StateCode] = new OptionSetValue((int)Lead_StateCode.Open);
			lead[Lead.Fields.StatusCode] = new OptionSetValue((int)Lead_StatusCode.New);
			lead[Lead.Fields.Address1_Country] = "USA";
			lead[Lead.Fields.Address2_Country] = "USA";
			lead[Lead.Fields.MMo_Same_Address_Choice] = new OptionSetValue((int)MSeVTmGt_NoOrYes.Yes);

			if (!string.IsNullOrWhiteSpace(qrsPayload.submissionDate))
			{
				lead[Lead.Fields.MMo_Application_Received_Date] = DateTime.Parse(qrsPayload.submissionDate, null, DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal);
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.qrsQuoteId))
			{
				lead[Lead.Fields.MMo_QRS_QuoteId_Text] = qrsPayload.qrsQuoteId;
				lead[Lead.Fields.MMo_Integration_Source_Id_Text] = $"QRS-{qrsPayload.qrsQuoteId}";
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.qrsQuoteStatus))
			{
				var status = CrmHelper.QrsQuoteStatus(qrsPayload.qrsQuoteStatus);
				lead[Lead.Fields.MMo_QRS_Status_Choice] = new OptionSetValue(Convert.ToInt32(status));
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.quoteEffectiveDate))
			{
				lead[Lead.Fields.MMo_Effective_Date] = DateTime.Parse(qrsPayload.quoteEffectiveDate, null, DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal);
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.eligibleCount))
			{
				lead[Lead.Fields.MMo_Total_Eligible_Employees] = Convert.ToInt32(qrsPayload.eligibleCount);
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.totalCount))
			{
				lead[Lead.Fields.NumberOfEmployees] = Convert.ToInt32(qrsPayload.totalCount);
				lead[Lead.Fields.MMo_Total_Number_Of_Employees] = Convert.ToInt32(qrsPayload.totalCount);

				var count = CrmHelper.EmployeeCount(Convert.ToInt32(qrsPayload.totalCount));
				lead[Lead.Fields.MMo_Segment_Choice] = new OptionSetValue(count);
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.agencyId))
			{
				var accountId = GetAccountId(qrsPayload.agencyId, (int)MMo_AccountType_Code.Broker);
				if (accountId != Guid.Empty)
				{
					lead[Lead.Fields.MMo__Broker_Agency_Id] = new EntityReference(Account.EntityLogicalName, accountId);
				}
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.agentId))
			{
				var contact = GetContactId(qrsPayload.agentId);
				if (contact != null)
				{
					lead[Lead.Fields.MMo_Broker_Name_Id] = new EntityReference(Contact.EntityLogicalName, contact.Id);
				}
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.groupName))
			{
				lead[Lead.Fields.CompanyName] = qrsPayload.groupName;
				lead[Lead.Fields.Subject] = qrsPayload.groupName;
				lead[Lead.Fields.LastName] = qrsPayload.groupName;
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.streetAddress1))
			{
				lead[Lead.Fields.Address1_Line1] = qrsPayload.streetAddress1;
				lead[Lead.Fields.Address2_Line1] = qrsPayload.streetAddress1;
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.streetAddress2))
			{
				lead[Lead.Fields.Address1_Line2] = qrsPayload.streetAddress2;
				lead[Lead.Fields.Address2_Line2] = qrsPayload.streetAddress2;
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.city))
			{
				lead[Lead.Fields.Address1_City] = qrsPayload.city;
				lead[Lead.Fields.Address2_City] = qrsPayload.city;
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.state))
			{
				lead[Lead.Fields.Address1_StateOrProvince] = qrsPayload.state;
				lead[Lead.Fields.Address2_StateOrProvince] = qrsPayload.state;

				var stateId = GetStateId(qrsPayload.state);
				if (stateId != Guid.Empty)
				{
					lead[Lead.Fields.MMo_State_Id] = new EntityReference(HsL_State.EntityLogicalName, stateId);
					lead[Lead.Fields.MMo_State_Id_Mailing] = new EntityReference(HsL_State.EntityLogicalName, stateId);
				}
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.zip))
			{
				lead[Lead.Fields.Address1_PostalCode] = qrsPayload.zip;
				lead[Lead.Fields.Address2_PostalCode] = qrsPayload.zip;
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.countyCode))
			{
				var county = GetCountyId(qrsPayload.countyCode);
				if (county != null)
				{
					lead[Lead.Fields.Address1_County] = county[MMo_County.Fields.MMo_Name];
					lead[Lead.Fields.Address2_County] = county[MMo_County.Fields.MMo_Name];
					lead[Lead.Fields.MMo_Address1_County_Id] = new EntityReference(MMo_County.EntityLogicalName, county.Id);
					lead[Lead.Fields.MMo_Address2_County_Id] = new EntityReference(MMo_County.EntityLogicalName, county.Id);
					
					var region = (OptionSetValue)county[MMo_County.Fields.MMo_Region];
					if (region != null)
					{
						lead[Lead.Fields.MMo_Region_Choice] = region;
					}
				}
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.ein))
			{
				var accountId = GetAccountIdByEin(qrsPayload.ein);

				if (accountId == Guid.Empty)
				{
					accountId = await CreateAccount(qrsPayload, triggerTimestamp);
				}

				lead[Lead.Fields.CustomerId] = new EntityReference(Account.EntityLogicalName, accountId);
				lead[Lead.Fields.ParentAccountId] = new EntityReference(Account.EntityLogicalName, accountId);
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.sic))
			{
				lead[Lead.Fields.Sic] = qrsPayload.sic;
			}

			if (!string.IsNullOrWhiteSpace(qrsPayload.coverageIndicator))
			{
				var indicator = CrmHelper.CoverageIndicator(qrsPayload.coverageIndicator);
				lead[Lead.Fields.MMo_Coverage_Indicator_Choice] = new OptionSetValue(indicator);
			}

			var country = GetCountryId("USA");
			if (country != null)
			{
				lead[Lead.Fields.MMo_Country_Id] = new EntityReference(MMo_Country.EntityLogicalName, country.Id);
				lead[Lead.Fields.MMo_Country_Mailing_Id] = new EntityReference(MMo_Country.EntityLogicalName, country.Id);
			}

			// Set Owner
			var owner = GetSmallGroupSalesConsultant(qrsPayload.agentId);
			if (owner != null && owner.Id != Guid.Empty)
			{
				lead[Lead.Fields.OwnerId] = owner;
			}

			if (string.IsNullOrWhiteSpace(qrsPayload.agentId) || string.IsNullOrWhiteSpace(qrsPayload.agencyId) || string.IsNullOrWhiteSpace(qrsPayload.ein))
			{
				lead[Lead.Fields.MMo_FormFire_Review_Choice] = new OptionSetValue((int)MSeVTmGt_NoOrYes.Yes);
			}

			// Create the lead and then qualify it with the returned id
			var leadId = Guid.Empty;
			try
			{
				leadId = await _serviceClient.CreateAsync(lead);
			}
			catch (Exception ex)
			{
				// Check if the exception is due to missing privileges
				if (ex.Message.Contains("missing prvReadLead privilege"))
				{
					// Log the error
					_logger.LogError($"User does not have the required privileges: {ex.Message}");

					// Set the owner to the small group team instead.  Passing in null will return team.
					lead[Lead.Fields.OwnerId] = GetSmallGroupSalesConsultant(null);

					leadId = await _serviceClient.CreateAsync(lead);
				}
				else
				{
					// Rethrow the exception if it's not related to privileges
					throw;
				}
			}

			if (leadId == Guid.Empty)
			{
				throw new Exception($"Lead ID is empty.  Unable to qualify lead.");
			}

			// Qualify the lead
			var qualifyLeadRequest = new QualifyLeadRequest
			{
				CreateAccount = false,
				CreateContact = false,
				CreateOpportunity = true,
				LeadId = new EntityReference(Lead.EntityLogicalName, leadId),
				Status = new OptionSetValue((int)Lead_StatusCode.Commitment)
			};

			// Qualify the Lead
			QualifyLeadResponse qualifyLeadResponse = (QualifyLeadResponse)await _serviceClient.ExecuteAsync(qualifyLeadRequest);

			// Extract the new opportunity from the response
			var opportunityReference = qualifyLeadResponse.CreatedEntities?.FirstOrDefault(entity => entity.LogicalName == "opportunity");

			if (opportunityReference != null)
			{
				// Update New Opportunity's fields
				var opportunity = new Entity(Opportunity.EntityLogicalName, opportunityReference.Id)
				{
					[Opportunity.Fields.MMo_Opportunity_Type_Choice] = new OptionSetValue((int)MMo_Opportunity_Type_Gc.NewBusiness)
				};

				await _serviceClient.UpdateAsync(opportunity);
			}
		}

		public Task ScheduledJobs()
        {
            var openOpportunitiesFromOnBase = GetOpenOpportunitiesFromOnBase();
            return Task.CompletedTask;
        }

        private async Task<List<OpportunityData>?> GetOpenOpportunities()
        {
            var openOpportunities = new List<OpportunityData>();
            var opportunities = await CrmHelper.GetOpenOpportunities(_serviceClient);

            if (opportunities.Entities.Count == 0)
            {
                return openOpportunities; 
            }

            foreach (var entity in opportunities.Entities)
            {
                var opportunityData = new OpportunityData(); 

                if (entity.Contains(Opportunity.Fields.OpportunityId) && entity[Opportunity.Fields.OpportunityId] != null)
                {
                    opportunityData.OpportunityId = entity[Opportunity.Fields.OpportunityId].ToString();
                }

                if (entity.Contains(Opportunity.Fields.MMo_QRS_QuoteId_Text) && entity[Opportunity.Fields.MMo_QRS_QuoteId_Text] != null)
                {
                    opportunityData.QuoteId = entity[Opportunity.Fields.MMo_QRS_QuoteId_Text].ToString();
                }

                if (entity.Contains(Opportunity.Fields.MMo_Last_Tracked_OnBase_Queue) && entity[Opportunity.Fields.MMo_Last_Tracked_OnBase_Queue] != null)
                {
                    if (int.TryParse(entity[Opportunity.Fields.MMo_Last_Tracked_OnBase_Queue].ToString(), out int lastTracked))
                    {
                        opportunityData.LastTracked = lastTracked;
                    }
                }

                if (entity.Contains(Opportunity.Fields.MMo_Underwriting_Completed_Date) && entity[Opportunity.Fields.MMo_Underwriting_Completed_Date] != null)
                {
                    if (DateTime.TryParse(entity[Opportunity.Fields.MMo_Underwriting_Completed_Date].ToString(), out DateTime completedDate))
                    {
                        opportunityData.CompletedDate = completedDate;
                    }
                }

                openOpportunities.Add(opportunityData);
            }

            return openOpportunities;
        }



        private  string GetOpenOpportunitiesQuoteIds(List<OpportunityData>? opportunities)
        {
            var quotes = "";
            if (opportunities is { Count: 0 })
            {
                return quotes;
            }

            quotes = opportunities!.Aggregate(quotes, (current, opportunity) => $"{current} '{opportunity.QuoteId}',");

            if (quotes.Length <= 0)
            {
                return quotes;
            }
            quotes = quotes.Substring(0, quotes.Length - 1);

            return quotes;
        }

        //TODO: When the MBStatus is set to MU-COMPLETE set the CRM status to TBD, otherwise if the QueueNum is TBD then set the CRM status to TBD
        private async Task GetOpenOpportunitiesFromOnBase()
        {
            var opportunities = await GetOpenOpportunities();
            var openOpportunitiesQuoteIds = GetOpenOpportunitiesQuoteIds(opportunities);
            var onBaseQuotes = OnBaseHelper.GetOnBaseOpenRecords(openOpportunitiesQuoteIds);

            foreach (var quote in onBaseQuotes)
            {
                var opportunityRecord = opportunities?.FirstOrDefault(v => v.QuoteId?.Trim() == quote.QrsId?.Trim());
                if (opportunityRecord == null || string.IsNullOrWhiteSpace(opportunityRecord.OpportunityId))
                {
                    continue;
                }

                var opportunityId = new Guid(opportunityRecord.OpportunityId);
                var queueNum = opportunityRecord.LastTracked;
                var addQueueAutoPost = false;
                var addCompletedAutoPost = false;
                var currentQueueName = queueNum != null ? OnBaseHelper.GetQueueName(queueNum.ToString()) : string.Empty;
                var updateStatus = quote.MbStatus?.Trim() == "MU-COMPLETE";
				DateTime? completedDate = opportunityRecord.CompletedDate;

                if (updateStatus)
                {

                    if (completedDate == null)
                    {
                        completedDate = DateTime.UtcNow;
                        addCompletedAutoPost = true;
                    }
                }

                if (int.TryParse(quote.QueueNum, out var newQueueNum) && newQueueNum != queueNum)
                {
                    addQueueAutoPost = true;
                }

                
                UpdateOpportunityStatus(opportunityId, Convert.ToInt32(quote.QueueNum), updateStatus, completedDate);


                if (addQueueAutoPost && !string.IsNullOrWhiteSpace(quote.QueueName))
                {
                    var postMessage = $"OnBase queue changed from {currentQueueName} to {quote.QueueName}";
                    CreateAutoPost(opportunityId, postMessage);
                }

                if (addCompletedAutoPost)
                {
                    const string postMessage = $"OnBase Pre-screen record has been marked Complete";
                    CreateAutoPost(opportunityId, postMessage);
                }
            }
        }

        private void CreateAutoPost(Guid opportunityId, string postMessage)
        {
            var post = new Entity(Post.EntityLogicalName)
            {
                [Post.Fields.Text] = postMessage,
				[Post.Fields.Source] =  new OptionSetValue((int)Post_Source.AutoPost),
                [Post.Fields.RegardingObjectId] = new EntityReference(Opportunity.EntityLogicalName, opportunityId)
            };

            _serviceClient.Create(post);
        }
		public Guid GetAccountId(string agentId, int typeCode)
		{
			var accountId = Guid.Empty;
			var accounts = CrmHelper.GetAccountTaxId(_serviceClient, agentId, typeCode);

			if (accounts.Entities.Count <= 0) return accountId;
			var account = accounts.Entities[0];
			accountId = account.Id;

			return accountId;
		}

		public Guid GetAccountIdByEin(string ein)
		{
			var accountId = Guid.Empty;
			var accounts = CrmHelper.GetAccountByEin(_serviceClient, ein);

			var groupAccount = accounts.Entities
				.Where(x => x.GetAttributeValue<OptionSetValue>(Account.Fields.MMo_AccountType_Code).Value == (int)MMo_AccountType_Code.EmployerGroup)
				.FirstOrDefault();

			if (groupAccount != null)
			{
				// Group Account found for EIN
				accountId = groupAccount.Id;
			}
			else
			{
				// Group Account not found, loop for a Prospective Group Account.
				var prospectiveGroupAccount = accounts.Entities
					.Where(x => x.GetAttributeValue<OptionSetValue>(Account.Fields.MMo_AccountType_Code).Value == (int)MMo_AccountType_Code.ProspectiveGroup)
					.FirstOrDefault();

				if (prospectiveGroupAccount != null)
				{
					// Prospective Group Account found for EIN
					accountId = prospectiveGroupAccount.Id;
				}
			}

			return accountId;
		}

		public Entity? GetContactId(string agentId)
		{
			var contacts = CrmHelper.GetContactByTaxId(_serviceClient, agentId);

			if (contacts.Entities.Count <= 0) return null;
			var contact = contacts.Entities[0];

			return contact;
		}

		public Guid GetStateId(string abbreviation)
		{
			var stateId = Guid.Empty;
			var states = CrmHelper.GetStateByAbbreviation(_serviceClient, abbreviation);

			if (states.Entities.Count <= 0) return stateId;
			var state = states.Entities[0];
			stateId = state.Id;

			return stateId;
		}

		public Entity? GetCountyId(string code)
		{
			var counties = CrmHelper.GetCountyByCode(_serviceClient, code);

			if (counties.Entities.Count <= 0) return null;
			var county = counties.Entities[0];

			return county;
		}

		public Entity? GetCountryId(string name)
		{
			var countries = CrmHelper.GetCountryByName(_serviceClient, name);

			if (countries.Entities.Count <= 0) return null;
			var country = countries.Entities[0];

			return country;
		}

		public EntityReference GetSmallGroupSalesConsultant(string? agentId)
		{
			EntityReference? smallGroupSalesConsultantEntity = null;

			// Get Small Group Sales Consultant from Contact
			if (!string.IsNullOrWhiteSpace(agentId))
			{
				var contacts = CrmHelper.GetContactByTaxId(_serviceClient, agentId);

				if (contacts.Entities.Count > 1)
					_logger.LogWarning($"Multiple Contacts found for Agent ID:{agentId}");

				if (contacts.Entities.Count > 0 && contacts.Entities[0].Contains(Contact.Fields.MMo_Small_Group_Sales_Consultant_Id))
				{
					var userId = contacts.Entities[0].GetAttributeValue<EntityReference>(Contact.Fields.MMo_Small_Group_Sales_Consultant_Id).Id;
					smallGroupSalesConsultantEntity = new EntityReference(SystemUser.EntityLogicalName, userId);
				}
			}

			// Team Fallback logic if Small Group Sales Consultant not found from Agent.
			if (smallGroupSalesConsultantEntity == null)
			{
				var smallGroupTeamId = Guid.Empty;
				var smallGroupTeamIdString = Environment.GetEnvironmentVariable("small-group-team-id");

				if (!string.IsNullOrWhiteSpace(smallGroupTeamIdString))
				{
					try
					{
						smallGroupTeamId = new Guid(smallGroupTeamIdString);
					}
					catch
					{
						_logger.LogWarning("Unable to convert 'small-group-team-id' environment variable into a GUID.  Please check that the configuration has a valid unique identifier value.");
					}
				}

				smallGroupSalesConsultantEntity =  new EntityReference(Team.EntityLogicalName, smallGroupTeamId);
			}

			return smallGroupSalesConsultantEntity;
		}
	}

    class OpportunityData
    {
        public string? OpportunityId { get; set; }
        public string? QuoteId { get; set; }
        public DateTime? CompletedDate { get; set; }
        public int? LastTracked { get; set; }
    }
}
