﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MMO.Xrm.GroupSales.AzureFunctions.Framework.Interfaces;

namespace MMO.Xrm.GroupSales.AzureFunctions.Framework
{
    public class ServiceBusConfiguration : IServiceBusConfiguration
    {
        //public string ConnectionString { get; }
        //public string QueueName { get; }
        //public string TopicName { get; }
        //public string SubscriptionName { get; }
        public int MaxRetryCount { get; }

        public ServiceBusConfiguration(int maxRetryCount)
        {
            // TODO - Maybe some validation?

            //ConnectionString = connectionString;
            //QueueName = queueName;
            //TopicName = topicName;
            //SubscriptionName = subscriptionName;
            MaxRetryCount = maxRetryCount;
        }
    }

}
