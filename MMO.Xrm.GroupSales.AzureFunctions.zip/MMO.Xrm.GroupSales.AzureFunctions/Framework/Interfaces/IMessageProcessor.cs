﻿using Azure.Messaging.ServiceBus;
using Microsoft.Azure.Functions.Worker;
using MMO.Xrm.GroupSales.AzureFunctions.BusinessLogic.Interfaces;

namespace MMO.Xrm.GroupSales.AzureFunctions.Framework.Interfaces
{
    public interface IMessageProcessor
    {
        Task ProcessMessageAsync(ServiceBusReceivedMessage message, ServiceBusMessageActions messageActions, IMessageProcessingBusinessLogic logic, QrsMessageType qrsMessageType);
    }
}
