﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Azure.Messaging.ServiceBus;
using Microsoft.Azure.Functions.Worker;

namespace MMO.Xrm.GroupSales.AzureFunctions.Framework.Interfaces
{
    public interface IRetryHandler
    {
        Task RetryAsync(ServiceBusReceivedMessage message, ServiceBusMessageActions messageActions);
    }
}
