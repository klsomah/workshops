﻿using System.Globalization;
using Azure.Messaging.ServiceBus;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using MMO.Xrm.GroupSales.AzureFunctions.BusinessLogic;
using MMO.Xrm.GroupSales.AzureFunctions.BusinessLogic.Interfaces;
using MMO.Xrm.GroupSales.AzureFunctions.Framework.Interfaces;
using MMO.Xrm.AzureFunctions.Utility.Framework;
using MMO.Xrm.AzureFunctions.Utility.Framework.Interfaces;

namespace MMO.Xrm.GroupSales.AzureFunctions.Framework
{
    public class MessageProcessor : IMessageProcessor
    {
        private readonly ILogger<MessageProcessor> _logger;
        private readonly IRetryHandler _retryHandler;
		private readonly ILockService _lockService;

		public MessageProcessor(ILogger<MessageProcessor> logger, IRetryHandler retryHandler, ILockService lockService)
        {
            _logger = logger;
            _retryHandler = retryHandler;
			_lockService = lockService;
		}

        public async Task ProcessMessageAsync(ServiceBusReceivedMessage message, ServiceBusMessageActions messageActions, IMessageProcessingBusinessLogic logic, QrsMessageType qrsMessageType)
        {
			var messageContents = message.Body.ToString();

			if (string.IsNullOrWhiteSpace(messageContents))
			{
				throw new Exception("QRS Integration Payload is empty, exiting ProcessMessageAsync()");
			}

			var payload = System.Text.Json.JsonSerializer.Deserialize<QrsPayload>(messageContents);

			if (payload == null)
			{
				throw new Exception("Payload message is null after being deserialized.");
			}

			// Get the Trigger Timestamp from Service Bus Custome Properties
			var triggerTimestamp = GetTriggerTimestampFromServiceBusMessage(message);

			try
            {
				// Create a lock name that is unique to the source system, in this integration that's the QRS Quote Id
				var lockName = $"QRS-{payload.qrsQuoteId}";

				// Get the distributed lock
				var @lock = _lockService.GetLock(lockName);

				// attempt to obtain the lock, but only wait a maximum of X minutes
				await using (var handle = await @lock.TryAcquireAsync(TimeSpan.FromMinutes(2)))
				{
					if (handle != null)
					{
						switch (qrsMessageType)
						{
							case QrsMessageType.Submit:
								await logic.SubmitQuote(payload, triggerTimestamp);
								break;
							case QrsMessageType.Complete:
								await logic.CompleteQuote(payload, triggerTimestamp);
								break;
							case QrsMessageType.Renew:
								await logic.RenewQuote(payload, triggerTimestamp);
								break;
						}

						_logger.LogInformation("Successfully processed the message. Completing the message to remove from the bus.");
						await messageActions.CompleteMessageAsync(message);
					}
					else
					{
						// deadletter the message with a Label = "Couldn't obtain lock for lockName = '{lockName}'"
						throw new Exception($"Couldn't obtain lock for lockName = '{lockName}'");
					}
				}
            }
            catch (RetryException retryException)
            {
                _logger.LogWarning("Retrying the message due to the following exception: [{retryException}]", retryException);
                await _retryHandler.RetryAsync(message, messageActions);
            }
            catch (Exception exception)
            {
                _logger.LogError("Dead Lettering the message due to the following exception: [{exception}]", exception);
                await messageActions.DeadLetterMessageAsync(message, null, "GroupSalesException", exception.Message);
            }
        }

		private DateTime GetTriggerTimestampFromServiceBusMessage(ServiceBusReceivedMessage message)
		{
			DateTime triggerTimestamp = DateTime.MinValue;

			// Get TriggerTimestamp from Service Bus Message Custom Properties
			if (message.ApplicationProperties.TryGetValue("TriggerTimestamp", out var triggerTimestampValue))
			{
				_logger.LogInformation($"TriggerTimestamp: {triggerTimestampValue}");
			}
			else
			{
				_logger.LogInformation("TriggerTimestamp property not found.");
			}

			if (triggerTimestampValue is DateTime dt)
			{
				// If the variable is already a DateTime
				triggerTimestamp = dt;
			}
			else if (triggerTimestampValue is string str)
			{
				// If the variable is a string, try to parse it to DateTime
				if (DateTime.TryParse(str, null, DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal, out DateTime parsedDateTime))
				{
					triggerTimestamp = parsedDateTime;
				}
				else
				{
					_logger.LogWarning("The string could not be parsed to a valid DateTime.");
					//throw new FormatException("The string could not be parsed to a valid DateTime.");
				}
			}
			else
			{
				_logger.LogWarning("The triggeredTimestamp is neither a DateTime nor a string.");
				//throw new InvalidOperationException("The triggeredTimestamp is neither a DateTime nor a string.");
			}

			return triggerTimestamp;
		}
	}
}
