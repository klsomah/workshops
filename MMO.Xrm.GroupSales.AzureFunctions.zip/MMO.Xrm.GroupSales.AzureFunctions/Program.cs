using Azure.Core;
using Azure.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.PowerPlatform.Dataverse.Client;
using MMO.Xrm.GroupSales.AzureFunctions.BusinessLogic;
using MMO.Xrm.GroupSales.AzureFunctions.BusinessLogic.Interfaces;
using MMO.Xrm.GroupSales.AzureFunctions.Framework;
using MMO.Xrm.GroupSales.AzureFunctions.Framework.Interfaces;
using MMO.Xrm.AzureFunctions.Utility.Framework;
using MMO.Xrm.AzureFunctions.Utility.Framework.Interfaces;

var host = new HostBuilder()
    .ConfigureAppConfiguration(config =>
    {
        config.AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
            .AddEnvironmentVariables();
    })
    .ConfigureFunctionsWorkerDefaults()
    .ConfigureServices((context, services) =>
    {
        // ASB
        var maxRetryCount = context.Configuration.GetValue<int>("ServiceBusMaxRetryCount");
        services.AddSingleton<IServiceBusConfiguration>(new ServiceBusConfiguration(maxRetryCount));

        // Dataverse
        services.AddSingleton<IOrganizationServiceAsync2, ServiceClient>(sp =>
        {
            var crmUri =  Environment.GetEnvironmentVariable("crm-url"); //"https://medmutualdev.crm.dynamics.com/";
            var managedIdentity = new DefaultAzureCredential();
            if (string.IsNullOrEmpty(crmUri))
            {
                throw new InvalidOperationException("Crm-Url is not set in environment variable");
            }

            return new ServiceClient(new Uri(crmUri), tokenProviderFunction: async u =>
                (await managedIdentity.GetTokenAsync(
                    new TokenRequestContext(new[] { $"{crmUri}/.default" }))).Token
            );
        });

		// Distributed Lock
		services.AddSingleton<IBlobContainerClientFactory>(sp =>
		{
			var locksContainer = Environment.GetEnvironmentVariable("distributed-locks-container");
			var locksStorageAccount = Environment.GetEnvironmentVariable("distributed-locks-storage-account");
			if (string.IsNullOrEmpty(locksContainer) || string.IsNullOrEmpty(locksStorageAccount))
			{
				throw new InvalidOperationException("Distributed lock environment variables are not set");
			}
			string containerEndpoint = $"{locksStorageAccount}/{locksContainer}";
			return new BlobContainerClientFactory(containerEndpoint);
		});

		services.AddSingleton(sp =>
		{
			var factory = sp.GetRequiredService<IBlobContainerClientFactory>();
			return factory.CreateClient();
		});

		services.AddTransient<ILockService, LockService>();

		// Others
		services.AddScoped<IMessageProcessor, MessageProcessor>();
        services.AddScoped<IRetryHandler, ExponentialRetryHandler>();
        services.AddScoped<IMessageProcessingBusinessLogic, QrsBusinessLogic>();
    })
.Build();

await host.RunAsync();

