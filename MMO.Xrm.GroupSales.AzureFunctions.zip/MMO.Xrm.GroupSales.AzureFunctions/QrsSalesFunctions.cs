using System.Globalization;
using Azure.Messaging.ServiceBus;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using MMO.Xrm.GroupSales.AzureFunctions.BusinessLogic;
using MMO.Xrm.GroupSales.AzureFunctions.BusinessLogic.Interfaces;
using MMO.Xrm.GroupSales.AzureFunctions.Framework.Interfaces;
using Newtonsoft.Json;

namespace MMO.Xrm.GroupSales.AzureFunctions
{
    public class QrsSalesFunctions
    {
        private readonly ILogger<QrsSalesFunctions> _logger;
        private readonly IMessageProcessor _messageProcessor;
        private readonly IMessageProcessingBusinessLogic _messageHandler;

        public QrsSalesFunctions(ILogger<QrsSalesFunctions> logger, IMessageProcessor messageProcessor, 
            IMessageProcessingBusinessLogic messageHandler)
        {
            _logger = logger;
            _messageProcessor = messageProcessor;
            _messageHandler = messageHandler;
        }

		#region Message Processing

		#region Submit Functions
		[Function(nameof(QuoteSubmittedSalesFunctionServiceBusV1))]
		public async Task QuoteSubmittedSalesFunctionServiceBusV1(
			[ServiceBusTrigger("qrs/quote/create/v1", "%topic-subscription%", Connection = "ServiceBusConnection")]
			ServiceBusReceivedMessage message,
			ServiceBusMessageActions messageActions)
		{
			_logger.LogInformation("Message ID: {id}", message.MessageId);
			_logger.LogInformation("Message Body: {body}", message.Body);
			_logger.LogInformation("Message Content-Type: {contentType}", message.ContentType);

			// Complete the message
			await _messageProcessor.ProcessMessageAsync(message, messageActions, _messageHandler, QrsMessageType.Submit);
		}

		[Function(nameof(QuoteSubmittedSalesFunctionHTTPV1))]
		public async Task<IActionResult> QuoteSubmittedSalesFunctionHTTPV1([HttpTrigger(AuthorizationLevel.Function, "get", "post")] HttpRequestData req)
		{
			_logger.LogInformation("C# HTTP trigger function: [{functionName}]", nameof(QuoteSubmittedSalesFunctionHTTPV1));

			try
			{
				var triggerTimestamp = GetTriggerTimestampFromRequest(req);
				var qrsPayload = await ConvertHttpRequestDataToQrsPayload(req);

				if (qrsPayload == null)
				{
					_logger.LogWarning("Invalid payload received");
					return new BadRequestObjectResult("Invalid payload.");
				}

				await _messageHandler.SubmitQuote(qrsPayload, triggerTimestamp);

				_logger.LogInformation("Quote submitted successfully");
				return new OkObjectResult(new { message = "Quote submitted successfully." });
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, $"An error occurred while submitting the quote. {ex.Message}");
				var errorMessage = new { message = ex.Message, stackTrace = ex.StackTrace };
				return new ObjectResult(errorMessage)
				{
					StatusCode = StatusCodes.Status500InternalServerError
				};
			}
		}
		#endregion

		#region Complete Functions
		[Function(nameof(QuoteCompletedSalesFunctionServiceBusV1))]
		public async Task QuoteCompletedSalesFunctionServiceBusV1(
			[ServiceBusTrigger("qrs/quote/complete/v1", "%topic-subscription%", Connection = "ServiceBusConnection")]
			ServiceBusReceivedMessage message,
			ServiceBusMessageActions messageActions)
		{
			_logger.LogInformation("Message ID: {id}", message.MessageId);
			_logger.LogInformation("Message Body: {body}", message.Body);
			_logger.LogInformation("Message Content-Type: {contentType}", message.ContentType);

			// Complete the message
			await _messageProcessor.ProcessMessageAsync(message, messageActions, _messageHandler, QrsMessageType.Complete);
		}

		[Function(nameof(QuoteCompletedSalesFunctionHTTPV1))]
		public async Task<IActionResult> QuoteCompletedSalesFunctionHTTPV1([HttpTrigger(AuthorizationLevel.Function, "get", "post")] HttpRequestData req)
		{
			_logger.LogInformation("C# HTTP trigger function: [{functionName}]", nameof(QuoteCompletedSalesFunctionHTTPV1));

			try
			{
				var triggerTimestamp = GetTriggerTimestampFromRequest(req);
				var qrsPayload = await ConvertHttpRequestDataToQrsPayload(req);

				if (qrsPayload == null)
				{
					_logger.LogWarning("Invalid payload received");
					return new BadRequestObjectResult("Invalid payload.");
				}

				await _messageHandler.CompleteQuote(qrsPayload, triggerTimestamp);

				_logger.LogInformation("Quote completed successfully");
				return new OkObjectResult(new { message = "Quote completed successfully." });
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, $"An error occurred while completing the quote. {ex.Message}");
				var errorMessage = new { message = ex.Message, stackTrace = ex.StackTrace };
				return new ObjectResult(errorMessage)
				{
					StatusCode = StatusCodes.Status500InternalServerError
				};
			}
		}
		#endregion

		#region Renew Functions
		[Function(nameof(QuoteRenewSalesFunctionServiceBusV1))]
		public async Task QuoteRenewSalesFunctionServiceBusV1(
			[ServiceBusTrigger("qrs/quote/renew/v1", "%topic-subscription%", Connection = "ServiceBusConnection")]
			ServiceBusReceivedMessage message,
			ServiceBusMessageActions messageActions)
		{
			_logger.LogInformation("Message ID: {id}", message.MessageId);
			_logger.LogInformation("Message Body: {body}", message.Body);
			_logger.LogInformation("Message Content-Type: {contentType}", message.ContentType);

			// Complete the message
			await _messageProcessor.ProcessMessageAsync(message, messageActions, _messageHandler, QrsMessageType.Renew);
		}

		[Function(nameof(QuoteRenewSalesFunctionHTTPV1))]
		public async Task<IActionResult> QuoteRenewSalesFunctionHTTPV1([HttpTrigger(AuthorizationLevel.Function, "get", "post")] HttpRequestData req)
		{
			_logger.LogInformation("C# HTTP trigger function: [{functionName}]", nameof(QuoteRenewSalesFunctionHTTPV1));

			try
			{
				var triggerTimestamp = GetTriggerTimestampFromRequest(req);
				var qrsPayload = await ConvertHttpRequestDataToQrsPayload(req);

				if (qrsPayload == null)
				{
					_logger.LogWarning("Invalid payload received");
					return new BadRequestObjectResult("Invalid payload.");
				}

				await _messageHandler.RenewQuote(qrsPayload, triggerTimestamp);

				_logger.LogInformation("Quote renewed successfully");
				return new OkObjectResult(new { message = "Quote renewed successfully." });
			}
			catch (Exception ex)
			{
				_logger.LogError(ex, $"An error occurred while renewing the quote. {ex.Message}");
				var errorMessage = new { message = ex.Message, stackTrace = ex.StackTrace  };
				return new ObjectResult(errorMessage)
				{
					StatusCode = StatusCodes.Status500InternalServerError
				};
			}
		}
		#endregion

		private async Task<QrsPayload?> ConvertHttpRequestDataToQrsPayload(HttpRequestData req)
		{
			var requestBody = await new StreamReader(req.Body).ReadToEndAsync();
			var messageContent = string.IsNullOrEmpty(requestBody) ? "Request Body was empty" : requestBody;
			_logger.LogInformation(messageContent);

			var payload = JsonConvert.DeserializeObject<QrsPayload>(requestBody);
			return payload;
		}

		private DateTime GetTriggerTimestampFromRequest(HttpRequestData req)
		{
			string triggerTimestampString = req.Query["TriggerTimestamp"];

			DateTime.TryParse(triggerTimestampString, null, DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal, out DateTime triggerTimestamp);
			
			return triggerTimestamp;
		}
		#endregion

		#region Scheduled Jobs

		[Function(nameof(UpdateCRMWithOnBaseDataScheduledV1))]
		public async Task UpdateCRMWithOnBaseDataScheduledV1([TimerTrigger("0 */10 * * * *")] TimerInfo myTimer)
		{
			await _messageHandler.ScheduledJobs();
		}


		[Function(nameof(UpdateCRMWithOnBaseDataHTTPV1))]
		public IActionResult UpdateCRMWithOnBaseDataHTTPV1([HttpTrigger(AuthorizationLevel.Anonymous, "post")] HttpRequest req)
		{
			_messageHandler.ScheduledJobs();
			return new OkObjectResult(null);
		}

		#endregion
	}
}
